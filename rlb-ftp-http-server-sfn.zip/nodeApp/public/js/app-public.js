// public/app.js

document.addEventListener('DOMContentLoaded', () => {

    console.log('Client-side JavaScript is running v1.6');

    const messageElement = document.getElementById('message');
    const ws = new WebSocket(`ws://${window.location.host}`);

    //https://brightsign.atlassian.net/wiki/spaces/DOC/pages/420217548/networkstatus#NetworkStatusIpAddress
    const NetworkStatus = require("@brightsign/networkstatus");
    let networkStatus = new NetworkStatus();

    networkStatus.getInterfaceStatus("eth0")
    .then(function(data) {
        console.log("***General Interface Data***");
        console.log(JSON.stringify(data));
        console.log(data);
        playerIP = data.ipAddressList[0].address;

        console.log("player IP Address: ",playerIP)
        var message = "FTP Server destination folders http://" + playerIP + ":/public/media/group1";
        document.getElementById("ip-address").innerText = "INFO: " + message;

        var message2 = "folders available on the server are from group1 to group10";
        document.getElementById("info-message").innerText = "INFO: " + message2;
    })
    .catch(function(data) {
            console.log(JSON.stringify(data));
    });
    
    ws.onmessage = (event) => {
        const data = JSON.parse(event.data);
        console.log("UDP message: ",data.message);
    };    
    
    ws.onopen = () => {
        console.log('WebSocket connection established');
    };
    
    ws.onerror = (error) => {
        console.error('WebSocket error:', error);
        //messageElement.innerText = 'Failed to load message';
    };

    ws.onclose = () => {
        console.log('WebSocket connection closed');
    }; 

});